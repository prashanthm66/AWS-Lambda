import psycopg2
def lambda_handler(event,context):
	# conn_string = "dbname='test' port='5432' user='username' password='password' host='RDSEndpoint'"
	# conn = psycopg2.connect(conn_string)
	# cursor = conn.cursor()
	# cursor.execute("select system_env_host('prashanthreddydb.com')")
	# conn.commit()
	# cursor.close()
	print("working")